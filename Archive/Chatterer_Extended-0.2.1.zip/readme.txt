Chatterer Extended v0.2 for KSP 1.2.2 (by hoover2701)

This add-on for the formidable "Chatterer" mod by Athlonic will currently add 178 new kerbalized chatter-files for your hearing pleasure.

The audio files stem from the NASA Audio Archive (Missions Apollo 10, Apollo 13, STS-63 and ISS Expedition 18). The STS-63 and Expedition 18 thankfully feature female transmissions so Valentina's soundclips from the original "Chatterer" get some much needed support.


Installation instructions:

- place the "Chatterer_Extended"-folder in your MODS-directory
- open "Chatterer" in game
- in the "Chatterer" settings tab enable "Show advanced options"
- open the "Chatter" tab, click on "Chatter Sets" and type "apollo10", then press "Load", repeat this step with the following chatter sets: "apollo13", "sts63" and "expedition18"
- enjoy more babble


Dependencies:

- you need "Chatterer" obviously


Version history:

v0.2:
added ISS Expedition 18 Chatterer files (28 clips) and Apollo 13 Chatterer files (45 clips)
v0.1:
Apollo 10 Chatterer files (66 clips), STS-63 Chatterer files (39 clips)

**********************
This work is licensed under a Creative Commons Attribution 4.0 International License.
