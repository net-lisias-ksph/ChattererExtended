Chatterer Extended v0.4 for KSP 1.2.2 (by hoover2701)

This add-on for the formidable "Chatterer" mod by Athlonic will currently add 410 new kerbalized chatter-files for your hearing pleasure.

- Apollo 10 (120 clips)
- Apollo 13 (45 clips)
- STS-61c (98 clips) including female chatter
- STS-63 (39 clips) including female chatter
- Expedition 18 (28 clips) female set only
- Expedition 51 (80 clips) including female chatter

The audio files used for creating the soundclips stem from the NASA Audio Archive (https://archive.org/details/nasaaudiocollection). The STS61c, STS-63, Expedition 18 and Expedition 51 thankfully feature female transmissions so Valentina's soundclips from the original "Chatterer" get some much needed support.


Installation instructions:

- place the "Chatterer_Extended"-folder in your MODS-directory
- open "Chatterer" in game
- in the "Chatterer" settings tab enable "Show advanced options"
- open the "Chatter" tab, click on "Chatter Sets" and type "apollo10", then press "Load", repeat this step with the following chatter sets: "apollo13", "sts61c", "sts63", "expedition18" and "expedition51"
- enjoy more babble


Dependencies:

- you need "Chatterer" obviously


Version history:

v0.4
- added Expedition 51 Chatterer files (80 clips)
v0.3
- replaced faulty "capcom_23.ogg" (Apollo 10)
- added more Apollo 10-chatter (now 120 clips)
- added STS-61c Chatterer files (98 clips)
v0.2.1
- added version checker file
v0.2:
- added ISS Expedition 18 Chatterer files (28 clips) and Apollo 13 Chatterer files (45 clips)
v0.1:
- Apollo 10 Chatterer files (66 clips), STS-63 Chatterer files (39 clips)

**********************
This work is licensed under a Creative Commons Attribution 4.0 International License.
