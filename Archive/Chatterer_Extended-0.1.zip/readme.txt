Chatterer Extended v0.1 for KSP 1.2.2 (by hoover2701)

This add-on for the formidable "Chatterer" mod by Athlonic will add more than 100 new kerbalized chatter-files for your hearing pleasure.

The audio files stem from the NASA Audio Archive (Missions Apollo 10 and STS-63). I always thought there had to be more female chatter and the STS-63 mission luckily had a female Pilot (Eileen Collins) so I could choose from quite a few samples.

Installation instructions:
- place the "Chatterer_Extended"-folder in your MODS-directory
- open "Chatterer" in game
- in the "Chatterer" settings tab enable "Show advanced options"
- open the "Chatter" tab, click on "Chatter Sets" and type "apollo10", then press "Load", then type "sts63" and press "Load" once again
- enjoy more babble

Dependencies:
- you need "Chatterer" obviously

Version history:
0.1 Apollo 10 Chatterer files (66), STS-63 Chatterer files (39)

**********************
This work is licensed under a Creative Commons Attribution 4.0 International License.
